+++
title = "MacOS下使用Brew安装mpv"
date = "2016-11-09T20:57:22+08:00"
Description = "Install Mpv With Brew On Macos"
Tags = ["MPV", "MacOS"]
Categories = ["General"]
Draft = false

# additional params
bash = true
+++

意外得知Mac上的mpv非常好用，几乎是最好的播放器之一，如此安装即可：

<!--more-->

打开终端输入：

```bash
brew install mpv --with-bundle
brew linkapps mpv
```

完成。
