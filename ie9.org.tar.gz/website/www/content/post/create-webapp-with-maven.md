+++
title = "Maven创建Webapp"
date = "2015-04-28T15:04:39+08:00"
Description = "Create Webapp with Maven"
Tags = ["Maven"]
Categories = ["Maven", "Java"]
Draft = false

# additional params
bash = true
+++

绝大多数情况下，像这样的过程都由IDE代替了，其实它不过执行了这样的命令：

<!--more-->

```bash
mvn archetype:generate -DgroupId=com.chebaba.tmall -DartifactId=TmallService -DarchetypeArtifactId=maven-archetype-webapp -DinteractiveMode=false
```
