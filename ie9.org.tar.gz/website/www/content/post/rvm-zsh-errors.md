+++
title = "RVM报错: Warning: PATH set to RVM ruby but GEM_HOME and/or GEM_PATH not set"
date = "2016-06-19T11:52:03+08:00"
Description = "Rvm Zsh Errors"
Tags = ["RVM", "Ruby", "GEM_HOME", "GEM_PATH"]
Categories = ["Ruby"]
Draft = false

# additional params
bash = true
+++

像这样的Warning虽然不影响正常使用，但见到了总不是太爽，一定要解决之。另外，感觉对Ruby不是太感冒。

<!--more-->

安装完zsh和oh-my-zsh之后，终端打开一直报这个警告：

> Warning: PATH set to RVM ruby but GEM_HOME and/or GEM_PATH not set, see:
> https://github.com/wayneeseguin/rvm/issues/3212

解决办法就是：
在.bashrc和.zshrc这两个文件最后加上这段话

```bash
# Add RVM.
PATH=$PATH:$HOME/.rvm/bin # Add RVM to PATH for scripting
[[ -s "$HOME/.rvm/scripts/rvm" ]] && . "$HOME/.rvm/scripts/rvm"
```
