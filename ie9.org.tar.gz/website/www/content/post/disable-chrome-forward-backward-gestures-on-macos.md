+++
title = "禁用MacOS上Chrome双指向前向后手势"
date = "2010-04-04T11:03:57+08:00"
Description = "Disable Chrome Forward Backward Gestures On Macos"
Tags = ["MacOS", "Chrome", "Gestures"]
Categories = ["Genera"]
Draft = false

# additional params
bash = true
+++

最近在使用Chrome时因为手势造成了太多的误操作，耽误了不少时间，觉得麻烦，就直接全禁用了吧：

<!--more-->

```bash
defaults write com.google.Chrome.plist AppleEnableSwipeNavigateWithScrolls -bool FALSE
```
