+++
title = "MacOS下安装Sublime Text的LaTex中文支持"
date = "2016-06-26T00:00:13+08:00"
Description = "Install Sublime Text Latex On Macos"
Tags = ["MacOS", "Sublime Text", "LaTex"]
Categories = ["MacOS", "LaTex"]
Draft = false

# additional params
bash = true
katex = true
+++

转载的，但时间长了不记得出自哪里，同时也有针对自己实际操作有修改的地方。这个玩法不太常见，通常都有专业的工具去解决。

<!--more-->

### 1. 打开Sublime Text，按快捷键`Command+Shift+P`调出命令窗口，输入`Install`，安装`LaTexTools`；

### 2. 下载安装[Skim](https://sourceforge.net/projects/skim-app/files/latest/download)。然后按`Command+,`打开首选项，在`同步`标签中设置关联的程序，我们选择`Sublime Text`，或输入完整的路径`/Applications/Sublime\ Text\ 2.app/Contents/SharedSupport/bin/subl`；

### 3. 打开终端运行以下命令：

```bash
sudo tlmgr update --self
sudo tlmgr install latexmk
```

### 4. 为增加对中文的支持，在Sublime Text的LaTexTool用户设置中修改：

  4.1 在`builder_settings`中增加以下两个选项：

```
"program" : "xelatex",
"command" : ["latexmk", "-cd", "-e", "$pdflatex = 'xelatex -interaction=nonstopmode -synctex=1 %S %O'", "-f", "-pdf"],
```

  4.2 修改`viewer`的值为`preview`；

### 5. 测试代码：

```latex
\documentclass{article}
\usepackage{fontspec, xunicode, xltxtra}  
\setmainfont{Hiragino Sans GB}  

\title{Title}
\author{}

\begin{document}

\maketitle{}

\section{Introduction}

This is where you will write your content. 在这里写上内容。

\end{document}
```

保存后按`Command+B`，是不是看到编译的PDF了？
