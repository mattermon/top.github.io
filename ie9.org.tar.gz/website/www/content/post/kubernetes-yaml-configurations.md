+++
title = "Kubernetes YAML 配置文件简介"
date = "2018-05-18T15:30:14+08:00"
Description = "Kubernetes Yaml Configurations"
Tags = ["Kubernetes", "YAML"]
Categories = ["Cloud"]
Draft = false

# additional params
bash = true
yaml = true
+++

首先，Kubernetes的配置文件不止接收YAML/YML文件，还支持json格式，因为这两种格式在我看来没有太大的区别，重点想记录一下内容。

<!--more-->

通常，YAML文件是结合`kubectl`命令使用的，`kuberctl`命令官方文档在[这里](https://kubernetes.io/docs/concepts/configuration/overview/)，[YAML](http://yaml.org/)并不是Kubernetes独创的格式，它其实也是一个开源项目，YAML文件配置比JSON更简洁，号称配置文件界的Python语言，因为它最大的特色和Python类似——没有括号，靠缩进表示归属关系。

下面看一个示例：

```yaml
---
apiVersion: v1
kind: Pod
```

- `---` 相当于分隔符，当需要在一个文件中定义多个结构的时候使用；
- `apiVersion` 是配置文件的顶层节点，表示API的版本号，当前默认支持v1;
- `kind` 表示将要创建的资源类型，可选的值有：`pod`，`service`，`deployment`等等；

```yaml
metadata:
  name: nginx
  labels:
    app: nginx
```

- `metadata` 是配置文件的顶层节点，存储了当前节点的元数据，包括命名空间、名称、标签等；
- `name` 名称，会方便以后查看和操作；
- `labels` 标签，用以标识一个资源的键值对，用以供Kubernetes快速查找和筛选相应的服务，和微信里面的标签类似；

```yaml
...
spec:
  containers:
    - name: front-end
      image: nginx
      ports:
        - containerPort: 80
```

- `spec` 是配置文件的顶层节点，定义了包括container、storage、volume以及其他Kubernetes需要的参数；
- `containers` 其下包含了一系列容器的定义，相当于JSON的数组类型；
- `name`，`image`，`ports`，`containerPort` 基本上就一些基本定义了；

同时应该也发现一个规律：如果一个节点的子节点是数组类型，那么该节点的名称会是复数；同时，子节点如果是多个单词组成的，默认是驼峰语法，而值采用了中划线全小写的语法。

核心的内容就是这些，非常简单，剩下就是使用这个配置文件了。

基于文件创建资源的命令：

```bash
kubectl create -f some_file.yaml
# xxx "some_name" created
```

出现以上提示就表示创建成功了，接下来可以查看：

```bash
# for pod，其他同理
kubectl get pods
```

暂时就是这样。

