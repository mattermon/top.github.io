+++
title = "将HSQL导入MySQL中"
date = "2015-03-24T23:18:00+08:00"
Description = "将HSQL导入MySQL中"
Tags = ["Transfer", "HSQL", "MySQL"]
Categories = ["Database", "HSQL", "MySQL"]
Draft = false

# additional params
bash = true
+++

小项目，采用了比较小型的HSQL数据库，但在迁移时遇到不少问题，看来为了省事还是用常用的技术比较靠谱。

<!--more-->

下载`hsqldb.jar`、`mysql-connector-java-5.1.16-bin.jar`

第1步：windows命令行:

```bash
java -classpath D:\tmp\hsqldb.jar;D:\tmp\mysql-connector-java-5.1.16-bin.jar org.hsqldb.util.DatabaseManagerSwing 
```

第2步：出现Connect设计界面

第3步：在HSQL Database Manager界面，点击菜单"Tools"-->"Transfer"菜单，出现Source Database设置信息：
```
Type：HSQL Database Engine Standalone
Driver: org.hsqldb.jdbcDriver
URL:jdbc.hsqldb:file:D:\tmp\db\SynchDb3p7
User: SA
Password: 
```

第4步：点“ok”后，出现Target Database设置：
```
Type：Mysql connector/J
Driver: com.mysql.jdbc.Driver
URL:jdbc:mysql://127.0.0.1:3306/public
User: root
Password: 
```

第5步：点“ok”后，出现“HSQL Transfer Tool”转换设置，选public，点"select schema:source" ，然后再点“Start Transfer”进行转换。

> 注意：在转换前保证mysql服务器已经启动了，并且已经有"public"库。

在HSQL Database Manager界面，点击菜单"Tools"菜单灰色，是因为没有org\hsqldb\util\Transfer.class，可通过重新编译hsql源代码重新生成hsqldb.jar
