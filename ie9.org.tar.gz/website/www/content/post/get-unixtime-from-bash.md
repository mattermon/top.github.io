+++
title = "通过bash获取指定时间的unix格式"
date = "2017-06-26T18:04:15+08:00"
Description = "Get Unixtime From Bash"
Tags = ["Unix Time", "Date Time"]
Categories = ["General"]
Draft = false

# additional params
bash = true
+++

`bash`远比我们想像得强大，但正因为如此，我们并不必要掌握它的所有用法——记在这里就行了。

<!--more-->

获取当前时间戳

```bash
date '+%s'
```

获取指定日期的时间戳

```bash
date -j -f '%Y-%m-%d' '2016-09-14' '+%s'
```

