+++
title = "Remove DB2 on Linux"
date = "2014-12-02T23:12:21+08:00"
Description = "Remove DB2 on Linux"
Tags = ["Remove", "DB2", "Linux"]
Categories = ["Linux", "DB2", "Database"]

# additional params
bash = true
+++

在给客户部署程序时遇到了这个问题，为了测试专门在本机的虚拟机上安装并移除之，过程是这样的：

<!--more-->

Remove DB

```bash
su - db2inst1
db2 list db directory
db2 drop db <db name>
```

Remove Instance

```bash
su - root
cd <db2 dir>/instance
./db2ilist
./db2idrop <instance name>
```

Remove das

```bash
su - root
cd <db2 dir>/instance
./daslist
./dasdrop <das user>
```

Uninstall

```bash
su - root
cd <db2 dir>/install
./db2_deinstall -a
```

Remove user (db2inst1,db2fenc1,dasusr1)

```bash
userdel -r <username>
```

