+++
title = "Remove SQL Server 2008 Completely"
date = "2013-10-04T23:15:32+08:00"
Description = "Remove SQL Server 2008 Completely"
Tags = ["Remove", "SQL Server"]
Categories = ["Database", "Windows", "SQL Server"]
+++

对Windows越来越没有耐心了，整个系统无比复杂和混乱，没办法，高人总结了以下经验，给入了坑的同学们吧：

<!--more-->

最近在联通安装一台IBM X3850 X5的服务器，需要安装网管U2000，安装网管也要安装数据库。不过SQL Server 2008老是安装失败，弄了四天最后还是安装成功了，老是删除SQL Server都有经验了，跟大家介绍下吧。

在安装SQL时候可以先关闭UAC(用户账户控制)，防火墙也可以暂时关闭，安装完后再恢复。

先查看已安装的实例名，也可以连接企业管理时，查看本地实例
```
HKEY_LOCAL_MACHINE/SOFTWARE/Microsoft/Microsoft SQL Server/InstalledInstance
```
如果安装的实例多，可以先卸载实例：
```
CD %ProgramFiles%\Microsoft SQL Server\100\Setup Bootstrap\Release

setup.exe /ACTION=uninstall /FEATURES=Feature_List /INSTANCENAME=Instance_Name（自定义的实例名）

setup.exe /ACTION=uninstall /FEATURES=SQL,AS,BOL,SSMS /INSTANCENAME=MSSQLSERVER（默认实例名）
```
删除以下注册表子项（建议使用RegWorkshop工具查找比较快捷）：
```
HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\MSSQLServer
HKEY_LOCAL_MACHINE\Software\Microsoft\MSSQLServ65
HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Microsoft SQL Server
HKEY_LOCAL_MACHINE\Software\Microsoft\Microsoft SQL Server 7
HKEY_LOCAL_MACHINE\System\CurrentControlSet\Services\MSDTC
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MSFTPSVC
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MSSCNTRS
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MSSEARCH
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MSSINDEX
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MSSGTHRSVC
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MSSQLServer
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MSSGATHERVER
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SQLExecutive
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SQLServerAgent
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SQLSERVER AGENT
HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\MSSQLServerADHelper
HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Search卸载Microsoft Search服务
HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft下Microsoft SQL Server文件夹全部删除
HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall删除所有与SQL有关键值
```

手工删除安装目录，默认情况下位于：
```
C:\Program Files\Microsoft SQL Server
C:\Program Files (x86)\Microsoft SQL Server
C:\Users\Administrator\搜索”SQL”关键字进行删除
```
如果是数据库引擎安装失败，解决办法就是先解除安裝KB954459，再安裝SQL Server就会成功，msxml的更新版本不一定是KB954459，也可能比这个更新，安装好SQL后在更新补丁就行了。

重新安装SQL Server 2008 R2，如果安装错误则查找：

X:/Program Files/MicroSoft SQL Server/100/Setup Bootstrap/Log/下的Detail.txt文件，到最后一行找到错误信息

Error:MsiGetProductInfo 无法检索 Product Code 为“{B5153233-9AEE-4CD4-9D2C-4FAAC870DBE2}”的包的 ProductVersion。错误代码:1608；看到B5153233就是未卸载干净的注册表键值，在注册表中搜索“B5153233”和“323515B”删除所有的键值。

使用微软官方软件Windows Install Clean Up清理安装信息，删除所有SQL的安装信息。如果需要删除SQL残留的服务，可以使用SRVINSTW这个工具，请自行搜索下载。以上工作做完后，可以用CCleaner64之类的注册表清理工具清理一下，查找一下垃圾文件清理，重启电脑后再进行SQL Server 2008的安装。
