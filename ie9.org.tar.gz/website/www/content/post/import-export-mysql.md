+++
title = "MySQL 数据库导入导出sql文件"
date = "2015-03-31T14:20:22+08:00"
Description = "MySQL 数据库导入导出sql文件"
Tags = ["MySQL", "Import", "Export"]
Categories = ["MySQL", "Database"]
Draft = false

# additional params
bash = true
+++

好记性不如烂笔头：

<!--more-->

导出

```bash
mysqldump -uroot -p123456 database_name > script.sql
```

导入

```bash
mysql -uroot -p123456 database_name < script.sql
```
