+++
title = "Gem源修改"
date = "2016-11-07T22:51:02+08:00"
Description = "Gem Repository Modification"
Tags = ["Gem", "Ruby"]
Categories = ["Ruby"]
Draft = false

# additional params
bash = true
+++

唉，ruby自带的源已被墙，程序员表示忍辱负重：

<!--more-->

```bash
$ gem sources --remove https://rubygems.org/
$ gem sources -a https://ruby.taobao.org/
$ gem sources -l
```
