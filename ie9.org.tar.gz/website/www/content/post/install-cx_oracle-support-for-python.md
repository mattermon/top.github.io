+++
title = "Python安装cx_Oracle支持"
date = "2014-12-01T09:33:49+08:00"
Description = "Install Cx_oracle Support For Python"
Tags = ["Python", "Oracle"]
Categories = ["Oracle", "Python"]
Draft = false

# additional params
bash = true
+++

Oracle目前对Python支持得并不非常完美，配置过程略复杂。

<!--more-->

1. 下载支持文件

- [Oracle Instant Client Basic](http://www.oracle.com/technetwork/topics/intel-macsoft-096467.html)
- [Oracle Instant Client SDK](http://www.oracle.com/technetwork/topics/intel-macsoft-096467.html)

# 2. 配置信息

```bash
mkdir /Users/<username_here>/oracle
mv /Users/<username_here>/Downloads/instantclient-* /Users/<username_here>/oracle
cd /Users/<username_here>/oracle
unzip instantclient-basic-*.zip
unzip instantclient-sdk-*.zip
cd instantclient_12_1/sdk
unzip ottclasses.zip
```

# 3. 动态库软链接
```bash
cd ..
cp -R ./sdk/* .
cp -R ./sdk/include/* .
ln -s libclntsh.dylib.11.1 libclntsh.dylib
ln -s libocci.dylib.11.1 libocci.dylib
```

# 4. 修改配置文件

```bash
vim ~/.bash_profile
```

以下三行加入到~/.bash_profile中
```
export ORACLE_HOME=/Users/<username_here>/oracle/instantclient_12_1
export DYLD_LIBRARY_PATH=$ORACLE_HOME
export LD_LIBRARY_PATH=$ORACLE_HOME
```

# 5. 安装

```bash
source ~/.bash_profile
pip install cx_Oracle
```
