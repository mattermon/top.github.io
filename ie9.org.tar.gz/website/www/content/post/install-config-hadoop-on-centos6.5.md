+++
title = "CentOS 6.5上安装配置Hadoop"
date = "2016-09-26T07:02:30+08:00"
Description = "Install Config Hadoop On Centos6.5"
Tags = ["CentOS 6.5", "Hadoop"]
Categories = ["Linux", "Hadoop"]
Draft = false

# additional params
bash = true
xml = true
+++

一般地，学习资源通常会使用老旧的版本，一方面，老旧版本比较稳定，另一方面，老旧版本功能略少，结构清晰，便于理解。但以下教程是根据回忆默写出来的，不保证正确性，只为装装逼玩玩而已，要求不要太高了。

<!--more-->

# 1. 下载资源

- 最新版[JDK 1.8.0_92](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
- 最新版Hadoop[安装包](http://www.apache.org/dyn/closer.cgi/hadoop/core/)

# 2. 配置环境

## 2.1 JDK

### 2.1.1 安装

我们下载的是rpm包，所以这里直接安装：
```bash
rpm -ivh jdk1.8.0_92.rpm
```

### 2.1.2 环境变量配置

修改`/etc/profile`文件，也可以修改其他影响环境变量的文件
```
export JAVA_HOME=/usr/java/jdk1.8.0_92
export JRE_HOME=$JAVA_HOME/jre
export CLASS_PATH=.:$CLASS_PATH:$JAVA_HOME/lib:$JRE_HOME/lib
export PATH=$PATH:$JAVA_HOME/bin:$JRE_HOME/bin
```

## 2.2 下载安装Hadoop

将下载的hadoop安装包放到`/opt`目录下，解压出来：
```bash
tar xvzf hadoop-2.7.2.tar.gz ; rm -f hadoop-2.7.2.tar.gz 
```

配置环境变量，修改`/etc/profile`
```config
export HADOOP_HOME=/opt/hadoop-2.7.2
# 修改以下行
export PATH=$PATH:$JAVA_HOME/bin:$JRE_HOME/bin:$HADOOP_HOME/bin
```

# 3. 配置Hadoop

## 3.1 修改以下四个配置文件：

修改`etc/hadoop/hadoop-env.sh`
```bash
# 明确指定JDK路径
export JAVA_HOME=/usr/java/jdk1.8.0_92
```

修改`etc/hadoop/core-site.xml`
```xml
<configuration>
    <property>
        <name>hadoop.tmp.dir</name>
        <value>/hadoop</value>
    </property>
    <property>
        <name>dfs.name.dir</name>
        <value>/hadoop/name</value>
    </property>
    <property>
        <name>fs.default.name</name>
        <value>hdfs://centos:9000</value>
    </property>
</configuration>
```

> 注：
> 其中`centos`是我本机的hostname，需要在`/etc/hosts`中明确指定`127.0.0.1`或`::1`映射到这个hostname

修改`etc/hadoop/hdfs-site.xml`
```xml
<configuration>
    <property>
        <name>dfs.data.dir</name>
        <value>/hadoop/data</value>
    </property>
</configuration>
```

修改`etc/hadoop/mapred-site.xml`
```xml
<configuration>
    <property>
        <name>mapred.job.tracker</name>
        <value>centos:9001</value>
    </property>
</configuration>
```

## 3.2 初始化

执行命令对Hadoop进行格式化
```bash
hadoop namenode -format
```

## 3.3 启动Hadoop

```bash
sbin/start-all.sh
```

完毕！
