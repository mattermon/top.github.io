+++
title = "Python获取当前运行的类名和函数名"
date = "2015-01-02T22:58:54+08:00"
Description = "Get Current Class And Function Name With Python"
Tags = ["Python"]
Categories = ["Python", "Code"]
Draft = false
+++

为了写个比较好用的日志类，需要这些详细信息，所以查到以下方法，不过最终没用起来，总觉得不够优雅。

<!--more-->

方法一：

```python
import inspect

def get_current_function_name():
    return inspect.stack()[1][3]
class MyClass:
    def function_one(self):
        print "%s.%s invoked"%(self.__class__.__name__, get_current_function_name())
if __name__ == "__main__":
    myclass = MyClass()
    myclass.function_one()
```

方法二：

```python
import sys
def get_cur_info():
print sys._getframe().f_code.co_filename  #当前文件名，可以通过__file__获得
print sys._getframe().f_code.co_name  #当前函数名
print sys._getframe().f_lineno #当前行号
get_cur_info()
# 其他函数请参考：dir(sys._getframe())
```
