+++
title = "在Nginx下配置免费的HTTPS证书Let's Encrypt"
date = "2016-06-25T11:51:00+08:00"
Description = "在Nginx下配置免费的HTTPS证书Let's Encrypt"
Tags = ["Nginx", "Lets Encrypt"]
Categories = ["Server", "HTTPS"]

# additional params
bash = true
+++

搭建自己的网站的时候，当然希望采用HTTPS，不止是更安全。Let's Encrypt还是免费的证书服务，极客专属。

<!--more-->

首先，进入网站根目录，创建ssl目录，以下操作以ssl为工作目录。

<!--more-->

## 创建帐号

```bash
openssl genrsa 4096 > account.key
```

## 创建 CSR 文件

### 1. 创建 RSA 私钥（兼容性好）

```bash
openssl genrsa 4096 > domain.key
```

### 2. 创建 ECC 私钥

```bash
#secp256r1
openssl ecparam -genkey -name secp256r1 | openssl ec -out domain.key

#secp384r1
openssl ecparam -genkey -name secp384r1 | openssl ec -out domain.key
```

### 3. 生成CSR文件（使用交互方式创建 CSR）

```bash
openssl req -new -sha256 -key domain.key -out domain.csr
```

## 配置验证服务

### 1. 创建用于存放验证文件的目录

```bash
mkdir ~/www/challenges/
```

### 2. 修改Nginx配置

```config
server {
    server_name www.yoursite.com yoursite.com;

    location ^~ /.well-known/acme-challenge/ {
        alias /home/xxx/www/challenges/;
        try_files $uri =404;
    }

    location / {
        rewrite ^/(.*)$ https://yoursite.com/$1 permanent;
    }
}
```

## 获取网站证书

### 1. 下载acme-tiny脚本

```bash
wget https://raw.githubusercontent.com/diafygi/acme-tiny/master/acme_tiny.py
```

### 2. 指定账户私钥、CSR 以及验证目录，执行脚本

```bash
python acme_tiny.py --account-key ./account.key --csr ./domain.csr --acme-dir ~/www/challenges/ > ./signed.crt
```

### 3. 下载 Let's Encrypt 的中间证书

```bash
wget -O - https://letsencrypt.org/certs/lets-encrypt-x3-cross-signed.pem > intermediate.pem
cat signed.crt intermediate.pem > chained.pem

# 把根证书和中间证书合在一起
wget -O - https://letsencrypt.org/certs/isrgrootx1.pem > root.pem
cat intermediate.pem root.pem > full_chained.pem
```

### 4. 修改 Nginx 中有关证书的配置并 reload 服务即可

```config
ssl_certificate     ~/www/ssl/chained.pem;
ssl_certificate_key ~/www/ssl/domain.key;
```

## 配置自动更新

### 1. 创建脚本`renew.sh`

```bash
#!/bin/bash

cd /home/xxx/www/ssl/
python acme_tiny.py --account-key account.key --csr domain.csr --acme-dir /home/xxx/www/challenges/ > signed.crt || exit
wget -O - https://letsencrypt.org/certs/lets-encrypt-x3-cross-signed.pem > intermediate.pem
cat signed.crt intermediate.pem > chained.pem
service nginx reload
```

### 2. 修改crontab一月更新一次证书

```config
0 0 1 * * /home/xxx/shell/renew.sh >/dev/null 2>&1
```
