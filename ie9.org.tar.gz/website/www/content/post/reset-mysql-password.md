+++
title = "重置MySQL密码"
date = "2014-07-25T10:22:15+08:00"
Description = "Reset MySQL Password"
Tags = ["MySQL", "Password"]
Categories = ["MySQL"]
Draft = false

# additional params
bash = true
+++

会者不难，难者不会。

<!--more-->

编辑配置`vi /etc/my.cnf`

```
[mysqld]
skip-grant-tables
```

修改密码

```
use mysql;
UPDATE user SET Password=password('new-password') WHERE User='root';
```

重启，并把第一步中增加的选项注释

```bash
service mysqld restart
```
