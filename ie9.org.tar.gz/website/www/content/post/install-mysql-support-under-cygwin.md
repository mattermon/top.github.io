+++
title = "Cygwin下Python安装MySQL支持"
date = "2013-08-04T11:28:42+08:00"
Description = "Install MySQL Support under Cygwin"
Tags = ["Cygwin", "Python", "MySQL"]
Categories = ["MySQL", "Python"]
Draft = false

# additional params
bash = true
+++

Windows下安装配置环境总是无比蛋疼，还好，有人也遇到了这样的问题，并成功解决了：

<!--more-->

安装`MySQL-Python-xxx.exe`

安装依赖库

```bash
apt-cyg install libmysqlclient-devel
```

安装封装类

```bash
easy_install simplemysql
```
