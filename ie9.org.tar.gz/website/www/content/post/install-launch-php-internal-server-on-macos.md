+++
title = "Mac下安装运行PHP内置服务器"
date = "2016-11-05T01:47:55+08:00"
Description = "Install Launch Php Internal Server On Macos"
Tags = ["MacOS", "PHP"]
Categories = ["PHP"]
Draft = false

# additional params
bash = true
+++

一般来说，最新版本的Mac OS X已经内置了5.4版本的PHP，所以以下教程假设用户已经安装好了PHP。

<!--more-->

# 安装环境

## PHP

已内置

## MySQL

```bash
brew install mysql
```

## Memcached

```bash
brew install memcached
```

或

```bash
# 请安装与PHP版本一致的Memcached，如php=5.5，就安装php55-memcached
brew install homebrew/php/php55-memcached
```

安装完成之后，可以在找到`/usr/local/bin/memcached`，然后在终端执行：

```bash
telnet 127.0.0.1 11211
stats
#此处将显示memcached的各种状态信息
quit
```

如一切正常，开始安装Memcached的PHP扩展，从这里下载`http://pecl.php.net/package/memcache` Memcache的源码包，解压出来执行命令：

```bash
phpize
./configure
make
sudo make install
```

安装完成之后会提示以下信息

> Installing shared extensions: /usr/lib/php/extensions/no-debug-non-zts-20121212/

最后在`php.ini`文件中添加memcache扩展：

```bash
vim /etc/php.ini
```

在`Dynamic Extensions`这一节后面增加一行（路径以你本机实际路径这准）：

```ini
extension=/usr/lib/php/extensions/no-debug-non-zts-20121212/memcache.so
```

> 注：
> 如果提示没有`brew`命令，可通过以下命令安装

```bash
/usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
```

# 启动服务器

## Web服务器

直接启动PHP(>=5.4)内置的服务器，无需Nginx/Apache等环境

```bash
sudo php -S 0.0.0.0:80 -t /path/to/webroot
```

> 注：
> sudo 以管理员权限运行命令
> -S `大写的S`指定服务器网络地址和端口
> -t 指定serve的项目根目录

## MySQL服务器

```bash
mysql.server restart
```

> 注：
> 如果MySQL已经安装且配置完善，可通过命令直接启动服务。

## Memcached

```bash
memcached -p 11211 -d
```

> 注：
> -p 指定端口，默认11211
> -d 作为守护进程在后台运行，启动之后当前终端可关闭
