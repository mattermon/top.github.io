+++
title = "通过PL/SQL创建Oracle新用户"
date = "2015-06-04T15:39:29+08:00"
Description = "Create User With Plsql For Oracle"
Tags = ["PL/SQL", "Oracle"]
Categories = ["Database", "Oracle", "Code"]
Draft = false
+++

这段时间维护Oracle太频繁，像这样常用的命令真应该保存一下，每次只用复制就好：

<!--more-->

```sql
-- Create the user 
create user qq
  identified by ""
  default tablespace USERS
  temporary tablespace TEMP
  profile DEFAULT;
-- Grant/Revoke role privileges 
grant connect to qq;
grant dba to qq;  
grant resource to qq;  
-- Grant/Revoke system privileges 
grant alter any table to qq;
grant alter database to qq;
grant create any index to qq;
grant create any table to qq;
grant create any view to qq;
grant create table to qq;
grant create procedure to qq;
grant delete any table to qq;
grant drop any index to qq;
grant drop any view to qq;
grant drop any table to qq;
grant update any table to qq;
grant select any table to qq;
grant unlimited tablespace to qq; 
```
