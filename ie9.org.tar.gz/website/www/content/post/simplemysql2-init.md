+++
date = "2018-05-21T16:54:10+08:00"
Description = "Simplemysql2 Init"
title = "基于SimpleMysql的一个改进版本"
Tags = ["Python", "ORM", "MySQL"]
Categories = ["Develop"]
# featuredImage = "img/foobar.jpg"
Draft = false
+++

之前在做一些小的基于Python 2.7开发的时候用得比较多的一个MySQL库是[SimpleMysql](https://github.com/knadh/simplemysql)，星星不算最多，但是正如它描述中写的那样，非常简洁。

现在基于Python的开发已经全面转移到Python 3了，而SimpleMysql早已不再更新，对Python 3兼容性并不好，就抽时间作了一些兼容性的修改。

<!--more-->

其他改动就非常小了，如果要查询开发文档还可以去[SimpleMysql官网](http://nadh.in/code/simplemysql)查询。

由于实在太懒，不想拉出来一个独立的repo，反正就一个单文件，凑合看吧。

新的项目在这里：[github/top](https://github.com/top/language-Python/blob/master/simplemysql2.py)
