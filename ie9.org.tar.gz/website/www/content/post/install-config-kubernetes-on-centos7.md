+++
title = "CentOS 7安装配置Kubernetes(k8s)"
date = "2017-06-17T18:32:49+08:00"
Description = "Install Config Kubernetes on Centos7"
Tags = ["Linux", "Kubernetes", "k8s"]
Categories = ["Linux", "Cloud"]
Draft = false

# additional params
bash = true
yaml = true
+++

结合网上的资源，自己在虚拟机上配了一次，整体还是非常简单顺利的，有兴趣的朋友可以自己也试试。

<!--more-->

Kubernetes集群组件

* etcd 一个高可用的K/V键值对存储和服务发现系统
* flannel 实现夸主机的容器网络的通信
* kube-apiserver 提供kubernetes集群的API调用
* kube-controller-manager 确保集群服务
* kube-scheduler 调度容器，分配到Node
* kubelet 在Node节点上按照配置文件中定义的容器规格启动容器
* kube-proxy 提供网络代理服务

## 关闭系统防火墙

### 停止服务

```bash
systemctl stop firewall
systemctl disable firewall
```

### 禁止启动

```ini
# /etc/selinux/config
SELINUX=disabled
```

### 重启

## 配置master / etcd

### 配置

```ini
# /etc/etcd/etcd.conf
ETCD_LISTEN_CLIENT_URLS="http://localhost:2379,http://10.211.55.3:2379"
ETCD_ADVERTISE_CLIENT_URLS="http://localhost:2379,http://10.211.55.3:2379"
```

### 启动

```bash
systemctl restart etcd
systemctl enable etcd
```

### 检查 etcd cluster 状态

```bash
etcdctl cluster-health
```

### 检查 etcd 成员列表

```bash
etcdctl member list
```

## 配置master

### 配置kube-apiserver

```ini
# /etc/kubernetes/config
KUBE_MASTER="--master=http://10.211.55.3:8080"
```

```ini
# /etc/kubernetes/apiserver
KUBE_API_ADDRESS="--insecure-bind-address=0.0.0.0"
KUBE_ETCD_SERVERS="--etcd-servers=http://10.211.55.3:2379"
KUBE_SERVICE_ADDRESSES="--service-cluster-ip-range=10.254.0.0/16"
KUBE_ADMISSION_CONTROL="--admission-control=AlwaysAdmit"
```

### 配置 kube-controller-manager

```ini
# /etc/kubernetes/controller-manager
KUBE_CONTROLLER_MANAGER_ARGS=""
```

### 配置 kube-scheduler

```ini
# /etc/kubernetes/scheduler
KUBE_SCHEDULER_ARGS="--address=0.0.0.0"
```

### 启动服务

```bash
for i in kube-apiserver kube-controller-manager kube-scheduler ; do\
  systemctl restart $i ; \
  systemctl enable $i ; \
done
```

## 配置 node1

### 配置 etcd（在 master 上）

```bash
etcdctl set /atomic.io/network/config '{"Network":"172.16.0.0/16"}'
```

### 配置网络

```ini
# /etc/sysconfig/flanneld
FLANNELD_ETCD_ENDPOINTS="http://10.211.55.3:2379"
FLANNELD_ETCD_PREFIX="/atomic.io/network"
```

### 查看验证网络信息（在 master 上）

```bash
etcdctl get /atomic.io/network/config
etcdctl ls /atomic.io/network/subnets
etcdctl get /atomic.io/network/subnets/172.16.6.0-24 # 根据上面显示的信息查看
```

### 配置 kube-proxy

```ini
# /etc/kubernetes/proxy
KUBE_PROXY_ARGS="--bind-address=0.0.0.0"
```

### 配置 kubelet

```ini
# /etc/kubernetes/kubelet
KUBELET_HOSTNAME="--hostname-override=10.211.55.4"
KUBELET_API_SERVER="--api-server=http://10.211.55.3:8080"
```

### 启动服务

```bash
for i in flanneld kube-proxy kubelet docker ; do\
  systemctl restart $i ; \
  systemctl enable $i ; \
done
```

### 查看节点（在 master 上）

```bash
kubectl get nodes
```

### 建立 pod

```bash
export KUBERNETES_MASTER=http://10.211.55.3:8080
kubectl run nginx --image=nginx --port=80 --replicas=2
```

### 查看 pod（在 master 上）

```bash
kubectl get pods
kubectl get deployment
```

### 开放端口

```bash
# 会创建一个 service，将本地某个节点上的一个随机端口关联到容器中的80端口上。
kubectl expose deployment nginx --port=80 --type=LoadBalancer

# 查看 service
kubectl get service
```

### 外网访问

http://10.211.55.4:30255

### 删除 deployment 和 service

```bash
kubectl delete deployment nginx
kubectl delete service nginx
```

### 通过 yaml 文件方式创建 pod

```yaml
# nginx-pod.yaml
apiVersion: v1
kind: Pod
metadata:
  name: nginx
  labels:
    app: nginx
spec:
  containers:
  - name: nginx
    image: nginx
    imagePullPolicy: IfNotPresent
    ports:
    - containerPort: 80
  restartPolicy: Always
```

### 创建 pod

```bash
kubectl create -f nginx-pod.yaml
```

### 查看 pod

```bash
kubectl get pods
```

### 通过文件方式定义与之关联的 service

```yaml
# nginx-service.yaml
apiVersion: v1
kind: Service
metadata:
  name: nginx-service
spec:
  type: NodePort
  sessionAffinity: ClientIP
  selector:
    app: nginx
  ports:
  - port: 80
    nodePort: 30080
```

### 创建 service

```bash
kubectl create -f nginx-service.yaml
```

### 查看 service

```bash
kubectl get service
```

