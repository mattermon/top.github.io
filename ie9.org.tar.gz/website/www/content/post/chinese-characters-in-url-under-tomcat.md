+++
title = "解决Tomcat下URL包含中文时的乱码问题"
date = "2015-12-20T12:26:20+08:00"
Description = "Fix Chinese Characters in URL of Tomcat"
Tags = ["Tomcat", "乱码"]
Categories = ["Server", "Tomcat"]
Draft = false

# additional params
xml = true
+++

解决tomcat下的URL中文乱码问题的方法： 

<!--more-->

1）tomcat下的conf/server.xml

```xml
<Connector port="8080" maxHttpHeaderSize="8192" maxThreads="150" minSpareThreads="25" maxSpareThreads="75" enableLookups="false" redirectPort="8443" acceptCount="100" connectionTimeout="20000" disableUploadTimeout="true" URIEncoding="UTF-8"/>
```

2）另一处：这一处很关键，因为如果与apache结合时，端口转发时也要编码成UTF-8

```xml
<Connector port="8009" enableLookups="false" redirectPort="8443" protocol="AJP/1.3" URIEncoding="UTF-8" />
```

在URLEncoder.encode中指明用UTF-8编码

```xml
<a href=tag.jsp?tag=<%=URLEncoder.encode(blog.getTags(),"UTF-8")%>><strong><font color=red><%=blog.getTags() %>
```

解码时直接用`java.net.URLDecoder.decode(request.getParameter("tag"));
`即可解决乱码问题！
