+++
date = "{{ .Date }}"
Description = "{{ replace .TranslationBaseName "-" " " | title }}"
title = ""
Tags = [""]
Categories = [""]
# featuredImage = "img/foobar.jpg"
Draft = false

# additional params
bash = false
xml = false
nginx = false
go = false
yaml = false
mermaid = false
katex = false
+++
