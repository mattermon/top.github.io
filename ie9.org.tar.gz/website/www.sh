#!/bin/bash
ulimit -n 8192
./caddy -conf www -http2 -quic

