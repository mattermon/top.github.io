#!/bin/bash
echo 'starting update ie9.org'
git pull
hugo

echo 'starting update top.github.io'
cd top.github.io
git add . --force
git commit -m 'update'
git push -f
echo 'copying static resources'
cp -r -f ../static/* .
cd ..
